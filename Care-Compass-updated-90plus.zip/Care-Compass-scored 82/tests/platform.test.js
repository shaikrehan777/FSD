import test from 'node:test';
import assert from 'node:assert/strict';
import { INITIAL_HOSPITALS } from '../src/data/mockHospitals.js';
import { loadPersistedState, normalizeHospitals, normalizeReservations, normalizeAuditLogs } from '../src/utils/persistence.js';

test('storage loader safely falls back when JSON is malformed', () => {
  const result = loadPersistedState({ getItem: () => '{bad json' });
  assert.deepEqual(result.hospitals, INITIAL_HOSPITALS);
  assert.deepEqual(result.reservations, {});
  assert.deepEqual(result.auditLogs, []);
});
test('storage loader migrates valid legacy data and rejects invalid reservations', () => {
  const saved = { hospitals: INITIAL_HOSPITALS, reservations: { 'hosp-01': { ward: 'icu', code: 'CC-1234' }, unknown: { ward: 'icu', code: 'CC-9999' }, 'hosp-02': { ward: '__proto__', code: 'CC-0000' } }, auditLogs: [] };
  const result = loadPersistedState({ getItem: (key) => key.includes('v2') ? JSON.stringify(saved) : null });
  assert.equal(result.reservations['hosp-01'].code, 'CC-1234');
  assert.equal(Object.keys(result.reservations).length, 1);
});
test('hospital normalization rejects invalid coordinates and inconsistent bed counts', () => {
  const invalid = structuredClone(INITIAL_HOSPITALS); invalid[0].lat = 999;
  assert.deepEqual(normalizeHospitals(invalid), INITIAL_HOSPITALS);
  const invalidBeds = structuredClone(INITIAL_HOSPITALS); invalidBeds[0].beds.icu.available = invalidBeds[0].beds.icu.total + 1;
  assert.deepEqual(normalizeHospitals(invalidBeds), INITIAL_HOSPITALS);
});
test('reservation and audit normalizers discard malformed records and cap history', () => {
  assert.deepEqual(normalizeReservations([], INITIAL_HOSPITALS), {});
  assert.deepEqual(normalizeAuditLogs('bad'), []);
  const logs = Array.from({ length: 130 }, (_, i) => ({ id: String(i), hospitalName: 'Hospital', ward: 'icu', newAvailable: 1, timestamp: 'now' }));
  assert.equal(normalizeAuditLogs(logs).length, 100);
});
