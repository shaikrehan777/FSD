import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateHaversineDistance, estimateTravelMinutes } from '../src/utils/haversine.js';
import { clampBedCount, sanitizeText, isValidCoordinate } from '../src/utils/security.js';

test('Haversine distance is 0 for identical coordinates', () => {
  assert.equal(calculateHaversineDistance(17.4326, 78.4071, 17.4326, 78.4071), 0);
});

test('Haversine distance computes realistic Hyderabad inter-hospital distance', () => {
  const dist = calculateHaversineDistance(17.4326, 78.4071, 17.4435, 78.3665);
  assert.ok(dist > 3.5 && dist < 5.5, `Expected ~4.5 km, got ${dist}`);
  assert.ok(estimateTravelMinutes(dist) >= 3);
});

test('clampBedCount enforces non-negative and capacity upper bounds', () => {
  assert.equal(clampBedCount(-4, 20), 0);
  assert.equal(clampBedCount(35, 20), 20);
  assert.equal(clampBedCount(12, 20), 12);
});

test('sanitizeText strips angle brackets and javascript protocol', () => {
  const dirty = '<script>alert(1)</script>javascript:void(0) Cardiology';
  const clean = sanitizeText(dirty);
  assert.ok(!clean.includes('<') && !clean.includes('>'));
  assert.ok(!/javascript:/i.test(clean));
});


test('bed count rejects partial numeric strings and fractional values', () => {
  assert.equal(clampBedCount('4beds', 10), 0);
  assert.equal(clampBedCount(2.5, 10), 0);
});

test('coordinate validation rejects out-of-range and non-finite values', () => {
  assert.equal(isValidCoordinate(17.4, 78.4), true);
  assert.equal(isValidCoordinate(91, 78.4), false);
  assert.equal(isValidCoordinate(17.4, Infinity), false);
});

test('text sanitizer removes control characters', () => {
  assert.equal(sanitizeText('ward\u0000 update'), 'ward  update');
});
