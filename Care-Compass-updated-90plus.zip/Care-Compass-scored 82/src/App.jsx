import React, { useEffect, useMemo, useState } from 'react';
import {
  HeartPulse,
  Search,
  SlidersHorizontal,
  LocateFixed,
  Shield,
  BedDouble,
  AlertCircle,
  RotateCcw
} from 'lucide-react';
import { DEFAULT_USER_LOCATION, INITIAL_HOSPITALS } from './data/mockHospitals.js';
import { calculateHaversineDistance, estimateTravelMinutes } from './utils/haversine.js';
import { clampBedCount, sanitizeText } from './utils/security.js';
import { STORAGE_KEY, VALID_WARDS, loadPersistedState } from './utils/persistence.js';
import HospitalMap from './components/HospitalMap.jsx';
import HospitalCard from './components/HospitalCard.jsx';
import AdminConsole from './components/AdminConsole.jsx';

export default function App() {
  const [initialState] = useState(() => loadPersistedState(window.localStorage));
  const [hospitals, setHospitals] = useState(initialState.hospitals);
  const [userLocation, setUserLocation] = useState(DEFAULT_USER_LOCATION);
  const [activeTab, setActiveTab] = useState('finder');
  const [searchQuery, setSearchQuery] = useState('');
  const [wardFilter, setWardFilter] = useState('all');
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [sortBy, setSortBy] = useState('distance');
  const [selectedHospitalId, setSelectedHospitalId] = useState(INITIAL_HOSPITALS[0].id);
  const [reservations, setReservations] = useState(initialState.reservations);
  const [auditLogs, setAuditLogs] = useState(initialState.auditLogs);
  const [geoStatus, setGeoStatus] = useState('');

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ hospitals, reservations, auditLogs }));
    } catch {
      // Ignore storage quota errors
    }
  }, [hospitals, reservations, auditLogs]);

  const handleResetDemoData = () => {
    setHospitals(INITIAL_HOSPITALS);
    setReservations({});
    setAuditLogs([]);
    setUserLocation(DEFAULT_USER_LOCATION);
    setGeoStatus('Reset to baseline facility snapshot.');
  };

  const handleUseBrowserGps = () => {
    if (!navigator.geolocation) {
      setGeoStatus('Browser geolocation unavailable; using Jubilee Hills reference.');
      return;
    }
    setGeoStatus('Acquiring GPS coordinates...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = Number(pos.coords.latitude);
        const lng = Number(pos.coords.longitude);
        if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
          setGeoStatus('GPS returned invalid coordinates; using the reference location.');
          return;
        }
        setUserLocation({
          lat: Number(lat.toFixed(4)),
          lng: Number(lng.toFixed(4)),
          label: 'Live GPS Coordinates'
        });
        setGeoStatus('Updated to live GPS coordinates.');
      },
      () => {
        setGeoStatus('Permission denied; using Jubilee Hills reference.');
      },
      { timeout: 6000 }
    );
  };

  const enrichedHospitals = useMemo(() => {
    const cleanQuery = sanitizeText(searchQuery).toLowerCase();

    return hospitals
      .map((hosp) => {
        const distanceKm = calculateHaversineDistance(
          userLocation.lat,
          userLocation.lng,
          hosp.lat,
          hosp.lng
        );
        const etaMinutes = estimateTravelMinutes(distanceKm);
        return { ...hosp, distanceKm, etaMinutes };
      })
      .filter((hosp) => {
        if (cleanQuery) {
          const matchesName = hosp.name.toLowerCase().includes(cleanQuery);
          const matchesAddress = hosp.address.toLowerCase().includes(cleanQuery);
          const matchesSpec = hosp.specialties.some((s) => s.toLowerCase().includes(cleanQuery));
          if (!matchesName && !matchesAddress && !matchesSpec) return false;
        }

        if (wardFilter !== 'all' && hosp.beds[wardFilter].available <= 0) return false;

        if (onlyAvailable) {
          const openTotal =
            hosp.beds.icu.available +
            hosp.beds.general.available +
            hosp.beds.nicu.available +
            hosp.beds.isolation.available;
          return openTotal > 0;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'icu') return b.beds.icu.available - a.beds.icu.available;
        if (sortBy === 'general') return b.beds.general.available - a.beds.general.available;
        return a.distanceKm - b.distanceKm;
      });
  }, [hospitals, userLocation, searchQuery, wardFilter, onlyAvailable, sortBy]);

  const kpis = useMemo(
    () =>
      hospitals.reduce(
        (acc, h) => {
          acc.icu += h.beds.icu.available;
          acc.general += h.beds.general.available;
          acc.nicu += h.beds.nicu.available;
          acc.isolation += h.beds.isolation.available;
          return acc;
        },
        { icu: 0, general: 0, nicu: 0, isolation: 0 }
      ),
    [hospitals]
  );

  const handleUpdateBedCount = (hospitalId, wardKey, newAvailable, note = 'System update') => {
    if (!VALID_WARDS.includes(wardKey)) return;
    const targetHospital = hospitals.find((hospital) => hospital.id === hospitalId);
    if (!targetHospital) return;
    const safeNote = sanitizeText(String(note)).slice(0, 200) || 'System update';
    setHospitals((prev) =>
      prev.map((h) => {
        if (h.id !== hospitalId) return h;
        const clamped = clampBedCount(newAvailable, h.beds[wardKey].total);
        return {
          ...h,
          lastUpdated: 'Just now',
          beds: {
            ...h.beds,
            [wardKey]: { ...h.beds[wardKey], available: clamped }
          }
        };
      })
    );

    const target = hospitals.find((h) => h.id === hospitalId);
    if (target) {
      setAuditLogs((prev) => [
        {
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          hospitalName: target.name,
          ward: wardKey,
          newAvailable: clampBedCount(newAvailable, target.beds[wardKey].total),
          note: safeNote,
          timestamp: new Date().toLocaleTimeString()
        },
        ...prev
      ].slice(0, 100));
    }
  };

  const handleReserveBed = (hospitalId, wardKey) => {
    const target = hospitals.find((h) => h.id === hospitalId);
    if (!target || target.beds[wardKey].available <= 0 || reservations[hospitalId]) return;

    const code = `CC-${Math.floor(1000 + Math.random() * 9000)}`;
    handleUpdateBedCount(
      hospitalId,
      wardKey,
      target.beds[wardKey].available - 1,
      `Emergency bed hold (${code})`
    );
    setReservations((prev) => ({ ...prev, [hospitalId]: { ward: wardKey, code } }));
  };

  const handleReleaseBed = (hospitalId) => {
    const existing = reservations[hospitalId];
    const target = hospitals.find((h) => h.id === hospitalId);
    if (!existing || !target) return;

    handleUpdateBedCount(
      hospitalId,
      existing.ward,
      target.beds[existing.ward].available + 1,
      `Released hold (${existing.code})`
    );
    setReservations((prev) => {
      const next = { ...prev };
      delete next[hospitalId];
      return next;
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-600 rounded-lg">
              <HeartPulse className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-base sm:text-lg leading-tight">
                CareCompass: BedFinder Blitz
              </h1>
              <p className="text-[11px] text-slate-400">
                Real-Time Emergency Bed Triage & Haversine Proximity Routing
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetDemoData}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition"
              title="Reset mock bed counts"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset
            </button>
            <nav className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-lg">
              <button
                onClick={() => setActiveTab('finder')}
                className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold transition ${
                  activeTab === 'finder' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white'
                }`}
              >
                <BedDouble className="w-3.5 h-3.5" />
                Bed Finder
              </button>
              <button
                onClick={() => setActiveTab('admin')}
                className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold transition ${
                  activeTab === 'admin' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white'
                }`}
              >
                <Shield className="w-3.5 h-3.5" />
                Admin Console
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">Available ICU</div>
            <div className="text-2xl font-extrabold text-blue-600 mt-1">{kpis.icu}</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">General Ward</div>
            <div className="text-2xl font-extrabold text-emerald-600 mt-1">{kpis.general}</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">NICU / Pediatric</div>
            <div className="text-2xl font-extrabold text-indigo-600 mt-1">{kpis.nicu}</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">Isolation / ER</div>
            <div className="text-2xl font-extrabold text-amber-600 mt-1">{kpis.isolation}</div>
          </div>
        </section>

        {activeTab === 'admin' ? (
          <AdminConsole
            hospitals={hospitals}
            onUpdateBedCount={handleUpdateBedCount}
            auditLogs={auditLogs}
          />
        ) : (
          <>
            <section className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                <div className="md:col-span-5 relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search hospital, area, or specialty..."
                    className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="md:col-span-3 flex items-center gap-2">
                  <SlidersHorizontal className="w-4 h-4 text-slate-400 shrink-0" />
                  <select
                    value={wardFilter}
                    onChange={(e) => setWardFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  >
                    <option value="all">All Ward Types</option>
                    <option value="icu">ICU Beds</option>
                    <option value="general">General Ward</option>
                    <option value="nicu">NICU / Pediatric</option>
                    <option value="isolation">Isolation / ER</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  >
                    <option value="distance">Sort: Nearest</option>
                    <option value="icu">Sort: Most ICU</option>
                    <option value="general">Sort: Most General</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <button
                    onClick={handleUseBrowserGps}
                    className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-lg transition h-full"
                  >
                    <LocateFixed className="w-3.5 h-3.5 text-blue-600" />
                    Use My GPS
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
                <label className="inline-flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                  <input
                    type="checkbox"
                    checked={onlyAvailable}
                    onChange={(e) => setOnlyAvailable(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  Show only facilities with at least one available bed
                </label>

                <span className="text-slate-500">
                  {wardFilter !== 'all' ? `Showing facilities with ${wardFilter.toUpperCase()} capacity` : 'All ward types'} · Origin: <strong>{userLocation.label}</strong> ({userLocation.lat}, {userLocation.lng})
                  {geoStatus && <span className="text-blue-600 ml-2">• {geoStatus}</span>}
                </span>
              </div>
            </section>

            <HospitalMap
              hospitals={enrichedHospitals}
              userLocation={userLocation}
              selectedHospitalId={selectedHospitalId}
              onSelectHospital={setSelectedHospitalId}
            />

            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-slate-900 text-base">
                  Matched Facilities ({enrichedHospitals.length})
                </h2>
                <span className="text-xs text-slate-500">Haversine spherical routing</span>
              </div>

              {enrichedHospitals.length === 0 ? (
                <div className="bg-white border border-slate-200 rounded-xl p-8 text-center">
                  <AlertCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="font-semibold text-slate-800">No hospitals match your filters.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {enrichedHospitals.map((hospital) => (
                    <HospitalCard
                      key={hospital.id}
                      hospital={hospital}
                      isSelected={hospital.id === selectedHospitalId}
                      onSelect={setSelectedHospitalId}
                      onReserveBed={handleReserveBed}
                      onReleaseBed={handleReleaseBed}
                      activeReservation={reservations[hospital.id]}
                    />
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </main>
    </div>
  );
}
