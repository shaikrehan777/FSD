import { INITIAL_HOSPITALS } from '../data/mockHospitals.js';
export const STORAGE_KEY = 'carecompass_state_v3';
export const LEGACY_STORAGE_KEY = 'carecompass_state_v2';
export const VALID_WARDS = Object.freeze(['icu', 'general', 'nicu', 'isolation']);

export function normalizeHospitals(value) {
  if (!Array.isArray(value) || value.length === 0) return INITIAL_HOSPITALS;
  const baseline = new Map(INITIAL_HOSPITALS.map((hospital) => [hospital.id, hospital]));
  const valid = value.filter((hospital) => {
    if (!baseline.has(hospital?.id) || typeof hospital.name !== 'string' || !Number.isFinite(hospital.lat) || !Number.isFinite(hospital.lng) || hospital.lat < -90 || hospital.lat > 90 || hospital.lng < -180 || hospital.lng > 180) return false;
    return VALID_WARDS.every((ward) => {
      const bed = hospital.beds?.[ward];
      return Number.isSafeInteger(bed?.total) && bed.total >= 0 && Number.isSafeInteger(bed?.available) && bed.available >= 0 && bed.available <= bed.total;
    });
  });
  return valid.length === value.length && valid.length ? valid : INITIAL_HOSPITALS;
}
export function normalizeReservations(value, hospitals) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  const ids = new Set(hospitals.map((hospital) => hospital.id));
  return Object.fromEntries(Object.entries(value).filter(([id, reservation]) => ids.has(id) && reservation && VALID_WARDS.includes(reservation.ward) && typeof reservation.code === 'string' && reservation.code.length <= 32));
}
export function normalizeAuditLogs(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 100).filter((entry) => entry && typeof entry.id === 'string' && typeof entry.hospitalName === 'string' && VALID_WARDS.includes(entry.ward) && Number.isSafeInteger(entry.newAvailable) && entry.newAvailable >= 0 && typeof entry.timestamp === 'string');
}
export function loadPersistedState(storage) {
  try {
    const raw = storage.getItem(STORAGE_KEY) ?? storage.getItem(LEGACY_STORAGE_KEY);
    const saved = raw ? JSON.parse(raw) : {};
    const hospitals = normalizeHospitals(saved?.hospitals);
    return { hospitals, reservations: normalizeReservations(saved?.reservations, hospitals), auditLogs: normalizeAuditLogs(saved?.auditLogs) };
  } catch {
    return { hospitals: INITIAL_HOSPITALS, reservations: {}, auditLogs: [] };
  }
}
