/**
 * Sanitizes user-entered text before it is stored or used in search/audit labels.
 * React escapes text nodes automatically; this is defense-in-depth, not an HTML sanitizer.
 */
export function sanitizeText(input) {
  if (typeof input !== 'string') return '';
  return input
    .replace(/[<>]/g, '')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/javascript\s*:/gi, '')
    .replace(/on\w+\s*=/gi, '')
    .trim()
    .slice(0, 140);
}

/** Enforces a finite, whole-number bed count within [0, maxCapacity]. */
export function clampBedCount(value, maxCapacity) {
  const maxValue = Number(maxCapacity);
  const max = Number.isFinite(maxValue) ? Math.max(0, Math.trunc(maxValue)) : 0;
  const parsed = typeof value === 'number' ? value : Number(String(value).trim());
  if (!Number.isFinite(parsed) || !Number.isInteger(parsed)) return 0;
  return Math.max(0, Math.min(max, parsed));
}

/** Validates geographic coordinates before they are passed to mapping/distance code. */
export function isValidCoordinate(lat, lng) {
  return Number.isFinite(lat) && Number.isFinite(lng) &&
    lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
}
