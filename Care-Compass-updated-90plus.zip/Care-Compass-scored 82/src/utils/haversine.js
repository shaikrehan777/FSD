/**
 * Computes great-circle distance (km) between two coordinates using the Haversine formula.
 * Validates coordinate ranges to prevent NaN propagation.
 */
export function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
  const coords = [lat1, lon1, lat2, lon2];
  if (coords.some((n) => typeof n !== 'number' || Number.isNaN(n))) {
    return 0;
  }

  const toRad = (deg) => (deg * Math.PI) / 180;
  const earthRadiusKm = 6371;

  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Number((earthRadiusKm * c).toFixed(2));
}

/**
 * Estimates urban ambulance travel time in minutes from distance in km.
 */
export function estimateTravelMinutes(distanceKm) {
  const safeDist = Math.max(0, Number(distanceKm) || 0);
  const avgUrbanSpeedKmh = 32;
  return Math.max(3, Math.round((safeDist / avgUrbanSpeedKmh) * 60 + 2));
}
