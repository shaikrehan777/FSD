import React, { useEffect, useRef, useState } from 'react';
import { Navigation, AlertTriangle } from 'lucide-react';

export default function HospitalMap({ hospitals, userLocation, selectedHospitalId, onSelectHospital }) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef([]);
  const [leafletFailed, setLeafletFailed] = useState(false);

  useEffect(() => {
    let isMounted = true;

    async function renderMap() {
      try {
        const L = await import('leaflet');
        if (!isMounted || !mapContainerRef.current) return;

        if (!mapInstanceRef.current) {
          const map = L.map(mapContainerRef.current).setView(
            [userLocation.lat, userLocation.lng],
            12
          );
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors',
            maxZoom: 18
          }).addTo(map);
          mapInstanceRef.current = map;
        }

        const map = mapInstanceRef.current;
        markersRef.current.forEach((marker) => marker.remove());
        markersRef.current = [];

        const originPopup = document.createElement('div');
        const originTitle = document.createElement('strong');
        originTitle.textContent = 'Origin';
        originPopup.append(originTitle, document.createElement('br'), document.createTextNode(userLocation.label));
        const originMarker = L.circleMarker([userLocation.lat, userLocation.lng], {
          radius: 9,
          fillColor: '#2563eb',
          color: '#ffffff',
          weight: 3,
          fillOpacity: 1
        })
          .addTo(map)
          .bindPopup(originPopup);
        markersRef.current.push(originMarker);

        hospitals.forEach((hosp) => {
          const icuCount = hosp.beds.icu.available;
          const color = icuCount === 0 ? '#ef4444' : icuCount <= 3 ? '#f59e0b' : '#10b981';

          const popupContent = document.createElement('div');
          const hospitalTitle = document.createElement('strong');
          hospitalTitle.textContent = hosp.name;
          popupContent.append(hospitalTitle, document.createElement('br'), document.createTextNode(`ICU: ${icuCount}/${hosp.beds.icu.total} · Distance: ${hosp.distanceKm} km`));
          const marker = L.circleMarker([hosp.lat, hosp.lng], {
            radius: hosp.id === selectedHospitalId ? 12 : 9,
            fillColor: color,
            color: hosp.id === selectedHospitalId ? '#0f172a' : '#ffffff',
            weight: hosp.id === selectedHospitalId ? 3 : 2,
            fillOpacity: 0.92
          })
            .addTo(map)
            .bindPopup(popupContent);

          marker.on('click', () => onSelectHospital(hosp.id));
          markersRef.current.push(marker);
        });
      } catch {
        if (isMounted) setLeafletFailed(true);
      }
    }

    renderMap();
    return () => {
      isMounted = false;
    };
  }, [hospitals, userLocation, selectedHospitalId, onSelectHospital]);

  useEffect(() => {
    if (mapInstanceRef.current && selectedHospitalId) {
      const target = hospitals.find((h) => h.id === selectedHospitalId);
      if (target) {
        mapInstanceRef.current.setView([target.lat, target.lng], 13, { animate: true });
      }
    }
  }, [selectedHospitalId, hospitals]);

  if (leafletFailed) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-amber-700 font-semibold text-sm">
            <AlertTriangle className="w-4 h-4" />
            <span>Proximity Matrix (Offline Tile Fallback)</span>
          </div>
          <span className="text-xs text-slate-500">Origin: {userLocation.label}</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {hospitals.map((h) => (
            <button
              key={h.id}
              onClick={() => onSelectHospital(h.id)}
              className={`text-left p-3 rounded-lg border transition ${
                selectedHospitalId === h.id
                  ? 'border-blue-600 bg-blue-50'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="font-semibold text-sm text-slate-900 flex items-center justify-between">
                <span className="truncate">{h.name}</span>
                <span className="text-xs font-mono text-blue-700 ml-2">{h.distanceKm} km</span>
              </div>
              <div className="text-xs text-slate-500 mt-1">
                ICU: <strong className="text-slate-800">{h.beds.icu.available}</strong> • General:{' '}
                <strong className="text-slate-800">{h.beds.general.available}</strong>
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <Navigation className="w-4 h-4 text-blue-600" />
          <h2 className="font-semibold text-slate-900 text-sm">Live Proximity Map</h2>
        </div>
        <div className="flex items-center gap-4 text-xs text-slate-600">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block" /> Origin
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" /> High ICU (&gt;3)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" /> Low ICU (1-3)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" /> Full (0)
          </span>
        </div>
      </div>
      <div ref={mapContainerRef} className="w-full h-72 bg-slate-100" />
    </div>
  );
}
