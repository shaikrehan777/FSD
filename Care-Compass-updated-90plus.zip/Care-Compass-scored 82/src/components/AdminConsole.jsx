import React, { useState } from 'react';
import { Lock, Unlock, Plus, Minus, ClipboardList, ShieldCheck, AlertCircle } from 'lucide-react';
import { clampBedCount, sanitizeText } from '../utils/security.js';

const DISPATCH_PASSCODE = 'ADMIN2026';

export default function AdminConsole({ hospitals, onUpdateBedCount, auditLogs }) {
  const [authenticated, setAuthenticated] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');
  const [selectedId, setSelectedId] = useState(hospitals[0]?.id || '');
  const [note, setNote] = useState('');

  const handleAuth = (e) => {
    e.preventDefault();
    if (passcode.trim() === DISPATCH_PASSCODE) {
      setAuthenticated(true);
      setError('');
      setPasscode('');
    } else {
      setError('Invalid passcode. Use ADMIN2026 to access dispatcher controls.');
    }
  };

  if (!authenticated) {
    return (
      <div className="max-w-md mx-auto bg-white border border-slate-200 rounded-xl p-6 shadow-sm mt-6">
        <div className="flex items-center gap-2.5 text-slate-900 font-bold text-lg">
          <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
            <Lock className="w-5 h-5" />
          </div>
          <h2>Hospital Dispatcher Console</h2>
        </div>
        <p className="text-sm text-slate-600 mt-2">
          Enter dispatcher credentials to reconcile ward bed counts and record audit entries.
        </p>
        <form onSubmit={handleAuth} className="mt-4 space-y-3">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
              Passcode
            </label>
            <input
              type="password"
              value={passcode}
              onChange={(e) => setPasscode(e.target.value)}
              placeholder="ADMIN2026"
              className="w-full px-3.5 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          {error && (
            <div className="flex items-center gap-1.5 text-xs text-red-600 bg-red-50 border border-red-200 p-2.5 rounded-lg">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
          <button
            type="submit"
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-lg transition"
          >
            Unlock Console
          </button>
        </form>
      </div>
    );
  }

  const activeHospital = hospitals.find((h) => h.id === selectedId) || hospitals[0];

  const handleAdjust = (wardKey, delta) => {
    const ward = activeHospital.beds[wardKey];
    const nextCount = clampBedCount(ward.available + delta, ward.total);
    const safeNote = sanitizeText(note) || 'Manual ward reconciliation';
    onUpdateBedCount(activeHospital.id, wardKey, nextCount, safeNote);
    setNote('');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <div>
              <h2 className="font-bold text-slate-900">Ward Capacity Manager</h2>
              <p className="text-xs text-slate-500">Bounds-checked live updates with audit trail logging.</p>
            </div>
          </div>
          <button
            onClick={() => setAuthenticated(false)}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 px-3 py-1.5 rounded-lg"
          >
            <Unlock className="w-3.5 h-3.5" /> Lock Session
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Facility</label>
            <select
              value={activeHospital.id}
              onChange={(e) => setSelectedId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
            >
              {hospitals.map((h) => (
                <option key={h.id} value={h.id}>
                  {h.name} ({h.tier})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Shift / Audit Note</label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g., Discharged 2 ICU step-down patients"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-5">
          {Object.entries(activeHospital.beds).map(([wardKey, counts]) => (
            <div key={wardKey} className="border border-slate-200 rounded-xl p-4 bg-slate-50">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-500">{wardKey} Ward</div>
              <div className="mt-2 flex items-baseline justify-between">
                <span className="text-2xl font-extrabold text-slate-900">{counts.available}</span>
                <span className="text-xs text-slate-500">of {counts.total} total</span>
              </div>
              <div className="mt-3 flex items-center gap-2">
                <button
                  onClick={() => handleAdjust(wardKey, -1)}
                  disabled={counts.available <= 0}
                  className="flex-1 inline-flex items-center justify-center py-1.5 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 disabled:opacity-40 text-slate-800"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleAdjust(wardKey, 1)}
                  disabled={counts.available >= counts.total}
                  className="flex-1 inline-flex items-center justify-center py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <ClipboardList className="w-4 h-4 text-blue-600" />
          <h3 className="font-bold text-slate-900 text-sm">Dispatcher Audit Trail</h3>
        </div>
        {auditLogs.length === 0 ? (
          <p className="text-xs text-slate-500">No capacity changes recorded yet.</p>
        ) : (
          <div className="divide-y divide-slate-100 max-h-64 overflow-y-auto">
            {auditLogs.map((log) => (
              <div key={log.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div>
                  <span className="font-semibold text-slate-900">{log.hospitalName}</span>{' '}
                  <span className="text-slate-600">
                    updated <strong>{log.ward.toUpperCase()}</strong> to{' '}
                    <strong className="text-blue-700">{log.newAvailable}</strong> beds
                  </span>
                  <span className="text-slate-400 ml-2">— "{log.note}"</span>
                </div>
                <span className="font-mono text-[11px] text-slate-400">{log.timestamp}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
