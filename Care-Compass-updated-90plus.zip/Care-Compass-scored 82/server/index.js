import express from 'express';
import cors from 'cors';

const DEFAULT_FACILITIES = [
  { id: 'hosp-01', name: 'Apollo Health City', capacity: { icu: 32, general: 180, nicu: 18, isolation: 20 }, beds: { icu: 8, general: 42, nicu: 5, isolation: 6 } },
  { id: 'hosp-03', name: 'AIG Hospitals', capacity: { icu: 40, general: 220, nicu: 20, isolation: 24 }, beds: { icu: 11, general: 54, nicu: 6, isolation: 9 } }
];
const WARDS = new Set(['icu', 'general', 'nicu', 'isolation']);

export function createApp({ facilities = structuredClone(DEFAULT_FACILITIES) } = {}) {
  const app = express();
  const allowedOrigin = process.env.CLIENT_ORIGIN;
  app.disable('x-powered-by');
  app.use(cors(allowedOrigin ? { origin: allowedOrigin } : { origin: false }));
  app.use(express.json({ limit: '16kb', strict: true }));
  const audit = [];
  app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'care-compass-api', timestamp: new Date().toISOString() }));
  app.get('/api/hospitals', (_req, res) => {
    res.set('Cache-Control', 'no-store');
    res.json({ count: facilities.length, hospitals: facilities });
  });
  app.get('/api/audit', (_req, res) => {
    res.set('Cache-Control', 'no-store');
    res.json({ count: audit.length, entries: audit.slice(0, 100) });
  });
  app.patch('/api/hospitals/:id/beds', (req, res) => {
    const facility = facilities.find((item) => item.id === req.params.id);
    if (!facility) return res.status(404).json({ error: 'Hospital not found' });
    const { ward, available, note = 'API bed-count update' } = req.body || {};
    if (typeof ward !== 'string' || !WARDS.has(ward) || !Object.hasOwn(facility.beds, ward)) return res.status(400).json({ error: 'Invalid ward type' });
    if (typeof available !== 'number' || !Number.isSafeInteger(available) || available < 0 || available > facility.capacity[ward]) {
      return res.status(400).json({ error: `Available beds must be an integer between 0 and ${facility.capacity[ward]}` });
    }
    if (typeof note !== 'string' || note.length > 200 || /[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(note)) return res.status(400).json({ error: 'Audit note must be plain text under 200 characters' });
    const previous = facility.beds[ward];
    facility.beds[ward] = available;
    audit.unshift({ id: `${Date.now()}-${audit.length}`, hospitalId: facility.id, hospitalName: facility.name, ward, previous, available, note: note.replace(/[<>]/g, '').trim() || 'API bed-count update', timestamp: new Date().toISOString() });
    if (audit.length > 100) audit.length = 100;
    return res.json({ facility, audit: audit[0] });
  });
  app.use((error, _req, res, _next) => {
    if (error instanceof SyntaxError && 'body' in error) return res.status(400).json({ error: 'Invalid JSON request body' });
    return res.status(500).json({ error: 'Internal server error' });
  });
  return app;
}
const app = createApp();
const PORT = process.env.PORT || 4000;
if (process.env.NODE_ENV !== 'test') app.listen(PORT, () => console.log(`CareCompass API listening on http://localhost:${PORT}`));
export default app;
